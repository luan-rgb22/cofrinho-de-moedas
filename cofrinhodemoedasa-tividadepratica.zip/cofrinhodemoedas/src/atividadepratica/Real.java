package atividadepratica;

public class Real extends Moeda {
	// Construtor da classe Real que inicializa a moeda com seu valor
    public Real(double valor) {
        super(valor, "Brasil");
    }

    @Override
    public double converterParaReal() {
        return valor; // Já está em Real.
    }
}
