package atividadepratica;

public class Euro extends Moeda {
	// Chama o construtor da classe Moeda com o valor do Euro e o país "Euro"
    public Euro(double valor) {
        super(valor, "Euro");
    }

    @Override// Método para converter o valor do Euro para Real
    public double converterParaReal() {
        double cotacaoEuro = 6.0; // Exemplo de cotação do Euro
        return valor * cotacaoEuro;// Retorna o valor convertido para Real
    }
}

