package atividadepratica;
public abstract class Moeda {
    protected double valor;
    protected String pais;
    
    public Moeda(double valor, String pais) {
        this.valor = valor;
        this.pais = pais;
    }

    public double getValor() {
        return valor;
    }

    public String getPais() {
        return pais;
    }

    // Método abstrato para converter para Real
    public abstract double converterParaReal();
}

