package atividadepratica;
//Classe principal que contém o menu de interação com o usuário
import java.util.Scanner; // Importa a classe Scanner para ler entradas do usuário
public class Principal {//Classe principal que contém o menu de interação com o usuário
		
 
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Cofrinho cofrinho = new Cofrinho();
	        
	        while (true) {// Mostra o menu para o usuário
	            System.out.println("1. Adicionar Moeda");
	            System.out.println("2. Remover Moeda");
	            System.out.println("3. Listar Moedas");
	            System.out.println("4. Calcular Total em Real");
	            System.out.println("5. Sair");
	            System.out.print("Escolha uma opção: ");
	            int opcao = scanner.nextInt();// Lê a opção escolhida pelo usuário

	            switch (opcao) {
	                case 1://opçao para adicionar moeda
	                    System.out.print("Digite o tipo de moeda (1-Dólar, 2-Euro, 3-Real): ");
	                    int tipoMoeda = scanner.nextInt();// tipo de moeda
	                    System.out.print("Digite o valor da moeda: ");
	                    double valor = scanner.nextDouble();//valor da moeda
	                    switch (tipoMoeda) {
	                        case 1:
	                            cofrinho.adicionarMoeda(new Real(valor)); // Adiciona um Real
	                            break;
	                        case 2:
	                            cofrinho.adicionarMoeda(new Dolar(valor));// Adiciona um dolar
	                            break;
	                        case 3:
	                            cofrinho.adicionarMoeda(new Euro(valor));// Adiciona um euro
	                            break;
	                        default:
	                            System.out.println("Opção inválida.");
	                    }
	                    break;
	                case 2:
	                    //  remoção de moedas aqui (pode ser por tipo ou valor)
	                    System.out.println("Remoção de moeda ainda não implementada.");
	                    break;
	                case 3:
	                    cofrinho.listarMoedas();
	                    break;
	                case 4:
	                    System.out.println("Total em Real: " + cofrinho.calcularTotal());
	                    break;
	                case 5:
	                    System.out.println("Saindo...");
	                    scanner.close();
	                    return; // Encerra o programa
	                default:
	                    System.out.println("Opção inválida.");
	            }
	        }
	    }
}


