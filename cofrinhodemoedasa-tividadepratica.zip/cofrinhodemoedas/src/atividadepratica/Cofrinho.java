package atividadepratica;
import java.util.ArrayList;

public class Cofrinho {// Classe que representa o Cofrinho, onde as moedas são armazenadas
    private ArrayList<Moeda> moedas;

    public Cofrinho() {
        moedas = new ArrayList<>();// Atributo que contém a lista de moedas
    }

    public void adicionarMoeda(Moeda moeda) {
    }

    public void removerMoeda(Moeda moeda) {
        moedas.remove(moeda);
    }

    public void listarMoedas() {// Método para listar todas as moedas no Cofrinho
        for (Moeda moeda : moedas) {
            System.out.println(moeda.getPais() + " - " + moeda.getValor() + " " + moeda.getPais());
        }
    }
    // Método para calcular o total em Real, convertendo as moedas
    public double calcularTotal() {
        double total = 0.0;
        for (Moeda moeda : moedas) {
            total += moeda.converterParaReal();// Converte para Real e soma ao total
        }
        return total;// Retorna o total calculado
    }
}


