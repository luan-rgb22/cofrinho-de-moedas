package atividadepratica;

public class Dolar extends Moeda {
	// Construtor da classe Dólar que inicializa a moeda com seu valor
    public Dolar(double valor) {
        super(valor, "EUA");
    }

    @Override  // Método para converter o valor do Dólar para Real
    public double converterParaReal() {
        double cotacaoDolar = 5.70; //  cotação do Dólar
        return valor * cotacaoDolar;// Retorna o valor convertido para Real
    }
}